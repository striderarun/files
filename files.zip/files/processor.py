import base64
import os
from typing import Dict
import io
from urllib import request
from PIL import Image


def download_image(url):
    with request.urlopen(url) as resp:
        buffer = resp.read()
    stream = io.BytesIO(buffer)
    img = Image.open(stream)
    img.save("0.png")


def convert_to_byte_array(url):
    download_image(url)
    image = open("0.png", "rb")  # open binary file in read mode
    image_read = image.read()
    image_64_encode = base64.b64encode(image_read)
    bytes_array = image_64_encode.decode("utf-8")
    os.remove("0.png")
    return bytes_array


def create_model_request(bytes_array):
    return [{"inputField": "picture", "dataType": "Base64 string", "data": bytes_array}]


class Processor:
    def preprocess(self, task_inputs: Dict):
        url = task_inputs['url']
        byte_array = convert_to_byte_array(url)
        return create_model_request(byte_array)

    def postprocess(self, results: Dict):
        prediction_obj = results['outputs'][0]
        prediction = prediction_obj['data'][0]
        prediction_response = {
            "prediction": "The handwritten digit looks like" + str(prediction)
        }
        return prediction_response
