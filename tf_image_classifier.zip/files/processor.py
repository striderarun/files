from typing import Dict
import io
from urllib import request
from PIL import Image
import classifier


def download_image(url):
    with request.urlopen(url) as resp:
        buffer = resp.read()
    stream = io.BytesIO(buffer)
    img = Image.open(stream)
    img.save('0.jpg')
    return '0.jpg'


def process(self, task_inputs: Dict):
    url = task_inputs['url']
    img_path = download_image(url)
    return classifier.classify(img_path)
